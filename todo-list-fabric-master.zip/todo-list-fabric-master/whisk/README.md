~/wsk action create util/natty ~/Git/Toodles/whisk/natty.js -a web-export true

https://openwhisk.ng.bluemix.net/api/v1/experimental/web/krhoyt@us.ibm.com_dev/util/natty.json/body?value=today
